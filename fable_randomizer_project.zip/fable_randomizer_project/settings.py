"""Настройки Fable Randomizer. Заполни значения перед запуском."""
from pathlib import Path

BOT_TOKEN = "ВСТАВЬ_ТОКЕН_ОТ_BOTFATHER"
BOT_USERNAME = "ИМЯ_БОТА_БЕЗ_СОБАКИ"
ADMIN_IDS = {123456789}  # Замени на свой числовой Telegram ID
WEBAPP_URL = "https://YOUR-DOMAIN.example"  # HTTPS URL размещённого Mini App
DB_PATH = Path(__file__).with_name("fable_randomizer.db")
HOST = "0.0.0.0"
PORT = 8000

# Скрытый относительный вес в розыгрыше: 0.01% за нового приглашённого, максимум 10%.
# Это НЕ процентные пункты вероятности выигрыша.
REFERRAL_RATE = 0.0001
MAX_REFERRAL_BONUS = 0.10
INIT_DATA_MAX_AGE = 86400
