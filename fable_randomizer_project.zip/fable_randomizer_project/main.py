"""
FABLE RANDOMIZER — Telegram contest bot + Mini App (modular project)
Python 3.11+

Install:
    pip install aiogram fastapi uvicorn

Configure settings.py before launch.
Run:
    python main.py

Admin commands:
    /addchannel @channel       Add a channel (bot must be admin there)
    /channels                  List saved channels
    /newcontest Title | Description
    /publish ID                Publish contest announcement to saved channels
    /finish ID                 Close contest and draw winner
    /mycontests                List your contests
    /stats                     Basic service statistics

User commands:
    /start [ref_USERID|contest_ID]
    /contests
    /join ID
    /myref

Notes:
- Mini App HTML is embedded in this same Python file and served by FastAPI.
- Public Mini App use requires HTTPS and WEBAPP_URL configured in BotFather/menu button.
- Referral reward is a hidden relative draw-weight modifier: 0.01% per referred
  new user (0.0001), capped at +10% relative weight. It is NOT a guaranteed
  percentage-point increase in win probability.
- This is a substantial MVP, not an audited production gambling/raffle platform.
  Test in a private Telegram channel before real use.
"""

import asyncio
import hashlib
import hmac
import html
import json
import os
import secrets
import time
from contextlib import suppress
from pathlib import Path
from urllib.parse import parse_qsl

import sqlite3
from aiogram import Bot, Dispatcher, F
from aiogram.filters import Command, CommandStart
from aiogram.types import (
    Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton,
    WebAppInfo
)
from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError
from fastapi import FastAPI, Header, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse
import uvicorn

# -------------------- CONFIG --------------------
from settings import (BOT_TOKEN, BOT_USERNAME, ADMIN_IDS, WEBAPP_URL, DB_PATH, HOST, PORT,
                      REFERRAL_RATE, MAX_REFERRAL_BONUS, INIT_DATA_MAX_AGE)

# -------------------- DATABASE --------------------
db = sqlite3.connect(DB_PATH, check_same_thread=False)
db.row_factory = sqlite3.Row
db.execute("PRAGMA foreign_keys=ON")
db.execute("PRAGMA journal_mode=WAL")
db.executescript("""
CREATE TABLE IF NOT EXISTS users(
 telegram_id INTEGER PRIMARY KEY, username TEXT, first_name TEXT,
 referred_by INTEGER, referral_count INTEGER NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS channels(
 id INTEGER PRIMARY KEY AUTOINCREMENT, chat_id INTEGER UNIQUE NOT NULL,
 username TEXT, title TEXT NOT NULL, added_by INTEGER NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS contests(
 id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL,
 description TEXT NOT NULL DEFAULT '', created_by INTEGER NOT NULL,
 active INTEGER NOT NULL DEFAULT 1, winner_id INTEGER,
 published_at TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS contest_channels(
 contest_id INTEGER NOT NULL REFERENCES contests(id) ON DELETE CASCADE,
 channel_id INTEGER NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
 PRIMARY KEY(contest_id, channel_id)
);
CREATE TABLE IF NOT EXISTS entries(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 contest_id INTEGER NOT NULL REFERENCES contests(id) ON DELETE CASCADE,
 telegram_id INTEGER NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(contest_id, telegram_id)
);
CREATE TABLE IF NOT EXISTS draw_logs(
 id INTEGER PRIMARY KEY AUTOINCREMENT, contest_id INTEGER NOT NULL,
 winner_id INTEGER NOT NULL, participants INTEGER NOT NULL,
 commitment TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
""")
db.commit()
DB_LOCK = asyncio.Lock()

def q(sql, args=()):
    return db.execute(sql, args)

def commit():
    db.commit()

def is_admin(uid: int) -> bool:
    return uid in ADMIN_IDS

def bot_link(payload: str = "") -> str:
    name = BOT_USERNAME.strip().lstrip("@")
    if not name or name.startswith("PUT_"):
        return ""
    return f"https://t.me/{name}" + (f"?start={payload}" if payload else "")

def esc(value) -> str:
    return html.escape(str(value or ""))

def register_user(tg_user, referrer_id=None):
    existing = q("SELECT telegram_id FROM users WHERE telegram_id=?", (tg_user.id,)).fetchone()
    if existing:
        return False
    valid_referrer = None
    if referrer_id and referrer_id != tg_user.id:
        ref = q("SELECT telegram_id FROM users WHERE telegram_id=?", (referrer_id,)).fetchone()
        if ref:
            valid_referrer = referrer_id
    q("""INSERT INTO users(telegram_id,username,first_name,referred_by)
         VALUES(?,?,?,?)""",
      (tg_user.id, tg_user.username, tg_user.first_name, valid_referrer))
    if valid_referrer:
        q("UPDATE users SET referral_count=referral_count+1 WHERE telegram_id=?",
          (valid_referrer,))
    commit()
    return True

def main_keyboard():
    rows = [
        [InlineKeyboardButton(text="🎁 Все конкурсы", callback_data="contests")],
        [InlineKeyboardButton(text="👥 Пригласить друзей", callback_data="referral")]
    ]
    if WEBAPP_URL.startswith("https://"):
        rows.insert(0, [InlineKeyboardButton(
            text="✨ Открыть Fable Randomizer",
            web_app=WebAppInfo(url=WEBAPP_URL)
        )])
    return InlineKeyboardMarkup(inline_keyboard=rows)

def contest_keyboard(contest_id):
    link = bot_link(f"contest_{contest_id}")
    if link:
        return InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="🎉 Участвовать", url=link)
        ]])
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="🎉 Участвовать", callback_data=f"join:{contest_id}")
    ]])

def user_referral_count(uid):
    row = q("SELECT referral_count FROM users WHERE telegram_id=?", (uid,)).fetchone()
    return row["referral_count"] if row else 0

def contest_channels(contest_id):
    return q("""SELECT ch.* FROM channels ch
        JOIN contest_channels cc ON cc.channel_id=ch.id
        WHERE cc.contest_id=? ORDER BY ch.id""", (contest_id,)).fetchall()

async def check_subscriptions(user_id: int, contest_id: int):
    required = contest_channels(contest_id)
    missing = []
    for channel in required:
        try:
            member = await bot.get_chat_member(channel["chat_id"], user_id)
            if member.status in ("left", "kicked"):
                missing.append(channel)
        except (TelegramBadRequest, TelegramForbiddenError):
            # If the bot cannot inspect membership, fail closed rather than silently allow.
            missing.append(channel)
    return missing

def contest_text(c):
    description = esc(c["description"])
    return (
        f"🎁 <b>{esc(c['title'])}</b>\n\n{description}\n\n"
        "Чтобы участвовать, нажми кнопку ниже. Если конкурс требует подписки, "
        "подпишись на указанные каналы и проверь участие."
    )

# -------------------- BOT --------------------
bot = Bot(BOT_TOKEN)
dp = Dispatcher()

@dp.message(CommandStart())
async def start(message: Message):
    args = (message.text or "").split(maxsplit=1)
    payload = args[1].strip() if len(args) > 1 else ""
    referrer_id = None
    contest_id = None
    if payload.startswith("ref_") and payload[4:].isdigit():
        referrer_id = int(payload[4:])
    elif payload.startswith("contest_") and payload[8:].isdigit():
        contest_id = int(payload[8:])

    register_user(message.from_user, referrer_id)
    await message.answer(
        "Привет! 👋 Добро пожаловать в <b>Fable Randomizer</b>!\n\n"
        "🎁 Приглашай друзей и увеличивай свои шансы на победу в конкурсах!\n\n"
        "Чем больше друзей присоединится по твоей ссылке, тем выше твои шансы выиграть!",
        reply_markup=main_keyboard(), parse_mode="HTML"
    )
    if contest_id:
        await attempt_join(message.from_user, contest_id, message.chat.id)

@dp.message(Command("contests"))
async def list_contests(message: Message):
    rows = q("SELECT * FROM contests WHERE active=1 ORDER BY id DESC").fetchall()
    if not rows:
        return await message.answer("Пока нет активных конкурсов.")
    for c in rows:
        count = q("SELECT COUNT(*) n FROM entries WHERE contest_id=?", (c["id"],)).fetchone()["n"]
        await message.answer(
            f"🎁 <b>{esc(c['title'])}</b>\n{esc(c['description'])}\n"
            f"Участников: {count}",
            reply_markup=contest_keyboard(c["id"]), parse_mode="HTML"
        )

@dp.callback_query(F.data == "contests")
async def cb_contests(callback: CallbackQuery):
    rows = q("SELECT * FROM contests WHERE active=1 ORDER BY id DESC").fetchall()
    if not rows:
        await callback.message.answer("Пока нет активных конкурсов.")
    for c in rows:
        count = q("SELECT COUNT(*) n FROM entries WHERE contest_id=?", (c["id"],)).fetchone()["n"]
        await callback.message.answer(
            f"🎁 <b>{esc(c['title'])}</b>\n{esc(c['description'])}\nУчастников: {count}",
            reply_markup=contest_keyboard(c["id"]), parse_mode="HTML"
        )
    await callback.answer()

@dp.callback_query(F.data == "referral")
async def cb_referral(callback: CallbackQuery):
    link = bot_link(f"ref_{callback.from_user.id}")
    if not link:
        link = "Администратору нужно заполнить BOT_USERNAME в настройках файла."
    await callback.message.answer(
        "👥 Приглашай друзей в Fable Randomizer!\n\n"
        "Чем больше друзей присоединится по твоей ссылке, тем выше твои шансы выиграть:\n"
        f"{link}", disable_web_page_preview=True
    )
    await callback.answer()

@dp.message(Command("myref"))
async def myref(message: Message):
    register_user(message.from_user)
    await message.answer(
        "Твоя ссылка для приглашения друзей:\n"
        f"{bot_link(f'ref_{message.from_user.id}')}\n\n"
        "Приглашения учитываются автоматически при первом запуске бота.",
        disable_web_page_preview=True
    )

async def attempt_join(tg_user, contest_id: int, reply_chat_id: int):
    register_user(tg_user)
    c = q("SELECT * FROM contests WHERE id=? AND active=1", (contest_id,)).fetchone()
    if not c:
        return await bot.send_message(reply_chat_id, "Конкурс не найден или уже завершён.")
    missing = await check_subscriptions(tg_user.id, contest_id)
    if missing:
        lines = ["Чтобы участвовать, подпишись на каналы:"]
        for ch in missing:
            url = f"https://t.me/{ch['username']}" if ch["username"] else ""
            lines.append(f"• {esc(ch['title'])}" + (f" — {url}" if url else ""))
        lines.append("\\nПосле подписки нажми «Проверить подписку» ниже.")
        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text=f"Проверить подписку ({contest_id})",
                                  callback_data=f"verify:{contest_id}")]
        ])
        return await bot.send_message(reply_chat_id, "\\n".join(lines), reply_markup=keyboard,
            parse_mode="HTML", disable_web_page_preview=True)
    try:
        q("INSERT INTO entries(contest_id,telegram_id) VALUES(?,?)", (contest_id, tg_user.id))
        commit()
        await bot.send_message(reply_chat_id, "✅ Готово! Ты участвуешь в конкурсе.")
    except sqlite3.IntegrityError:
        await bot.send_message(reply_chat_id, "Ты уже участвуешь в этом конкурсе.")

@dp.callback_query(F.data.startswith("join:"))
async def cb_join(callback: CallbackQuery):
    contest_id = int(callback.data.split(":")[1])
    await attempt_join(callback.from_user, contest_id, callback.from_user.id)
    await callback.answer()

@dp.callback_query(F.data.startswith("verify:"))
async def cb_verify(callback: CallbackQuery):
    contest_id = int(callback.data.split(":")[1])
    await attempt_join(callback.from_user, contest_id, callback.from_user.id)
    await callback.answer()

@dp.message(Command("join"))
async def join_command(message: Message):
    parts = (message.text or "").split()
    if len(parts) != 2 or not parts[1].isdigit():
        return await message.answer("Формат: /join ID")
    await attempt_join(message.from_user, int(parts[1]), message.chat.id)

@dp.message(Command("addchannel"))
async def add_channel(message: Message):
    if not is_admin(message.from_user.id):
        return await message.answer("Команда доступна только администраторам.")
    parts = (message.text or "").split(maxsplit=1)
    if len(parts) != 2:
        return await message.answer("Формат: /addchannel @channel")
    target = parts[1].strip()
    try:
        chat = await bot.get_chat(target)
        member = await bot.get_chat_member(chat.id, (await bot.me()).id)
        if member.status not in ("administrator", "creator"):
            return await message.answer("Сначала добавь бота администратором этого канала.")
        q("""INSERT INTO channels(chat_id,username,title,added_by)
             VALUES(?,?,?,?) ON CONFLICT(chat_id) DO UPDATE SET
             username=excluded.username,title=excluded.title""",
          (chat.id, chat.username, chat.title or target, message.from_user.id))
        commit()
        await message.answer(f"✅ Канал сохранён: {esc(chat.title)}", parse_mode="HTML")
    except Exception as e:
        await message.answer(f"Не удалось добавить канал. Проверь @username и права бота.\n{esc(e)}",
                             parse_mode="HTML")

@dp.message(Command("channels"))
async def channels_command(message: Message):
    rows = q("SELECT * FROM channels ORDER BY id").fetchall()
    if not rows:
        return await message.answer("Каналы ещё не добавлены. Используй /addchannel @channel")
    await message.answer("Сохранённые каналы:\n" + "\n".join(
        f"{r['id']}. {r['title']} (@{r['username'] or 'private'})" for r in rows
    ))

@dp.message(Command("newcontest"))
async def new_contest(message: Message):
    if not is_admin(message.from_user.id):
        return await message.answer("Команда доступна только администраторам.")
    raw = (message.text or "").partition(" ")[2].strip()
    if not raw:
        return await message.answer("Формат: /newcontest Название | описание")
    title, _, description = raw.partition("|")
    title = title.strip()
    if not title:
        return await message.answer("Укажи название конкурса.")
    cur = q("INSERT INTO contests(title,description,created_by) VALUES(?,?,?)",
            (title, description.strip(), message.from_user.id))
    contest_id = cur.lastrowid
    # При создании привязываем все сохранённые каналы как обязательные каналы подписки.
    channels = q("SELECT id FROM channels").fetchall()
    for ch in channels:
        q("INSERT OR IGNORE INTO contest_channels(contest_id,channel_id) VALUES(?,?)",
          (contest_id, ch["id"]))
    commit()
    link = bot_link(f"contest_{contest_id}")
    await message.answer(
        f"✅ Конкурс создан!\nID: {contest_id}\n"
        f"Каналы для проверки подписки: {len(channels)}\n"
        f"Ссылка для участников: {link or 'Настрой BOT_USERNAME в файле.'}\n\n"
        f"Публикация в сохранённые каналы: /publish {contest_id}"
    )

@dp.message(Command("publish"))
async def publish_contest(message: Message):
    if not is_admin(message.from_user.id):
        return await message.answer("Команда доступна только администраторам.")
    parts = (message.text or "").split()
    if len(parts) != 2 or not parts[1].isdigit():
        return await message.answer("Формат: /publish ID")
    contest_id = int(parts[1])
    c = q("SELECT * FROM contests WHERE id=?", (contest_id,)).fetchone()
    if not c:
        return await message.answer("Конкурс не найден.")
    channels = contest_channels(contest_id)
    if not channels:
        return await message.answer("Для этого конкурса нет сохранённых каналов. Добавь канал через /addchannel.")
    text = contest_text(c)
    sent, failed = 0, []
    for ch in channels:
        try:
            await bot.send_message(ch["chat_id"], text,
                reply_markup=contest_keyboard(contest_id), parse_mode="HTML")
            sent += 1
        except Exception as e:
            failed.append(f"{ch['title']}: {str(e)[:120]}")
    q("UPDATE contests SET published_at=CURRENT_TIMESTAMP WHERE id=?", (contest_id,))
    commit()
    result = f"Опубликовано в каналах: {sent}."
    if failed:
        result += "\nНе удалось:\n" + "\n".join(failed)
    await message.answer(result)

@dp.message(Command("mycontests"))
async def my_contests(message: Message):
    rows = q("SELECT * FROM contests WHERE created_by=? ORDER BY id DESC LIMIT 30",
             (message.from_user.id,)).fetchall()
    if not rows:
        return await message.answer("У тебя пока нет созданных конкурсов.")
    for c in rows:
        count = q("SELECT COUNT(*) n FROM entries WHERE contest_id=?", (c["id"],)).fetchone()["n"]
        status = "активен" if c["active"] else "завершён"
        await message.answer(f"#{c['id']} — {c['title']}\nСтатус: {status}\nУчастников: {count}")

@dp.message(Command("stats"))
async def stats(message: Message):
    if not is_admin(message.from_user.id):
        return await message.answer("Команда доступна только администраторам.")
    users = q("SELECT COUNT(*) n FROM users").fetchone()["n"]
    contests = q("SELECT COUNT(*) n FROM contests").fetchone()["n"]
    active = q("SELECT COUNT(*) n FROM contests WHERE active=1").fetchone()["n"]
    entries = q("SELECT COUNT(*) n FROM entries").fetchone()["n"]
    channels = q("SELECT COUNT(*) n FROM channels").fetchone()["n"]
    await message.answer(
        f"📊 Fable Randomizer\nПользователей: {users}\nКонкурсов всего: {contests}\n"
        f"Активных конкурсов: {active}\nУчастий: {entries}\nКаналов: {channels}"
    )

@dp.message(Command("finish"))
async def finish_contest(message: Message):
    if not is_admin(message.from_user.id):
        return await message.answer("Команда доступна только администраторам.")
    parts = (message.text or "").split()
    if len(parts) != 2 or not parts[1].isdigit():
        return await message.answer("Формат: /finish ID")
    contest_id = int(parts[1])
    c = q("SELECT * FROM contests WHERE id=? AND active=1", (contest_id,)).fetchone()
    if not c:
        return await message.answer("Активный конкурс не найден.")
    entries = q("""SELECT e.telegram_id,u.referral_count,u.first_name
        FROM entries e LEFT JOIN users u ON u.telegram_id=e.telegram_id
        WHERE e.contest_id=?""", (contest_id,)).fetchall()
    if not entries:
        return await message.answer("В конкурсе пока нет участников.")

    # Audit fingerprint: это техническая метка розыгрыша, а не криптографическое доказательство честности.
    seed = secrets.token_hex(32)
    commitment = hashlib.sha256(seed.encode()).hexdigest()
    rng = secrets.SystemRandom()
    weights = [
        1.0 + min((r["referral_count"] or 0) * REFERRAL_RATE, MAX_REFERRAL_BONUS)
        for r in entries
    ]
    winner = rng.choices(entries, weights=weights, k=1)[0]
    q("UPDATE contests SET active=0,winner_id=? WHERE id=?", (winner["telegram_id"], contest_id))
    q("INSERT INTO draw_logs(contest_id,winner_id,participants,commitment) VALUES(?,?,?,?)",
      (contest_id, winner["telegram_id"], len(entries), commitment))
    commit()
    await message.answer(
        f"🏆 Победитель конкурса «{esc(c['title'])}»:\n"
        f"{esc(winner['first_name'] or winner['telegram_id'])}\n"
        f"Участников: {len(entries)}\n"
        f"Технический fingerprint розыгрыша: <code>{commitment}</code>",
        parse_mode="HTML"
    )

@dp.message(Command("history"))
async def history(message: Message):
    rows = q("""SELECT c.id,c.title,c.winner_id,d.participants,d.commitment,d.created_at
        FROM draw_logs d JOIN contests c ON c.id=d.contest_id
        ORDER BY d.id DESC LIMIT 20""").fetchall()
    if not rows:
        return await message.answer("Завершённых конкурсов пока нет.")
    for r in rows:
        await message.answer(
            f"🏁 {r['title']}\nПобедитель ID: {r['winner_id']}\n"
            f"Участников: {r['participants']}\nHash: {r['commitment']}"
        )

# -------------------- MINI APP + API --------------------
app = FastAPI(title="Fable Randomizer")

def validate_init_data(init_data: str):
    if not init_data or ":" not in BOT_TOKEN:
        raise HTTPException(401, "Telegram initData required")
    data = dict(parse_qsl(init_data, keep_blank_values=True))
    received_hash = data.pop("hash", None)
    if not received_hash:
        raise HTTPException(401, "Invalid initData")
    check_string = "\n".join(f"{k}={v}" for k, v in sorted(data.items()))
    secret_key = hmac.new(b"WebAppData", BOT_TOKEN.encode(), hashlib.sha256).digest()
    calculated = hmac.new(secret_key, check_string.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(calculated, received_hash):
        raise HTTPException(401, "Invalid Telegram signature")
    try:
        auth_date = int(data.get("auth_date", "0"))
        if time.time() - auth_date > INIT_DATA_MAX_AGE:
            raise HTTPException(401, "Telegram session expired")
        return json.loads(data["user"])
    except (ValueError, KeyError, json.JSONDecodeError):
        raise HTTPException(401, "Invalid Telegram user data")

@app.get("/", response_class=HTMLResponse)
async def mini_app():
    return HTMLResponse(MINI_APP_HTML)

@app.get("/api/contests")
async def api_contests():
    rows = q("SELECT * FROM contests WHERE active=1 ORDER BY id DESC").fetchall()
    result = []
    for c in rows:
        count = q("SELECT COUNT(*) n FROM entries WHERE contest_id=?", (c["id"],)).fetchone()["n"]
        result.append({
            "id": c["id"], "title": c["title"], "description": c["description"],
            "participants": count, "join_url": bot_link(f"contest_{c['id']}")
        })
    return JSONResponse(result)

@app.get("/api/me")
async def api_me(x_telegram_init_data: str = Header(default="")):
    user = validate_init_data(x_telegram_init_data)
    row = q("SELECT referral_count FROM users WHERE telegram_id=?", (user["id"],)).fetchone()
    return {
        "telegram_id": user["id"], "first_name": user.get("first_name", ""),
        "referral_count": row["referral_count"] if row else 0,
        "referral_link": bot_link(f"ref_{user['id']}")
    }

@app.get("/api/contests/{contest_id}")
async def api_contest(contest_id: int):
    c = q("SELECT * FROM contests WHERE id=? AND active=1", (contest_id,)).fetchone()
    if not c:
        raise HTTPException(404, "Contest not found")
    count = q("SELECT COUNT(*) n FROM entries WHERE contest_id=?", (contest_id,)).fetchone()["n"]
    return {"id": c["id"], "title": c["title"], "description": c["description"],
            "participants": count}

MINI_APP_HTML = (Path(__file__).with_name("mini_app.html")).read_text(encoding="utf-8")

# -------------------- START BOTH SERVICES --------------------
async def run_bot():
    await dp.start_polling(bot)

async def run_api():
    config = uvicorn.Config(app, host=HOST, port=PORT, log_level="info")
    server = uvicorn.Server(config)
    await server.serve()

async def main():
    if "PUT_BOT_TOKEN_HERE" in BOT_TOKEN or ":" not in BOT_TOKEN:
        raise RuntimeError("Открой файл и укажи настоящий BOT_TOKEN.")
    if 123456789 in ADMIN_IDS:
        print("ВНИМАНИЕ: замени пример ADMIN_IDS на свой Telegram ID.")
    print("Fable Randomizer: bot + Mini App API starting...")
    await asyncio.gather(run_bot(), run_api())

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        print("Fable Randomizer stopped.")
